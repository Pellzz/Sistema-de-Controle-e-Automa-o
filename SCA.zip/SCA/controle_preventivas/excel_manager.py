import pandas as pd

ARQUIVO = r"D:\Projetos_Pessoais\SCA\controle_preventivas\maquinas.xlsx"
ABA = "PENDENTES"

COLUNAS_OBRIGATORIAS = ["ID", "Tecnico", "Maquina", "Descricao", "Data Prevista", "Status"]


def _validar_colunas(df: pd.DataFrame):
    df.columns = df.columns.astype(str).str.strip()
    faltando = [c for c in COLUNAS_OBRIGATORIAS if c not in df.columns]
    if faltando:
        raise ValueError(f"Colunas faltando no Excel: {faltando}. Encontradas: {list(df.columns)}")
    return df


def carregar_pendentes() -> pd.DataFrame:
    df = pd.read_excel(ARQUIVO, sheet_name=ABA)
    df = _validar_colunas(df)
    df = df[df["Status"].astype(str).str.strip().str.upper() == "PENDENTE"]
    return df


from openpyxl import load_workbook

ARQUIVO = r"D:\Projetos_Pessoais\SCA\controle_preventivas\maquinas.xlsx"
ABA = "PENDENTES"

def finalizar_preventiva(id_prev: int):
    wb = load_workbook(ARQUIVO)
    ws = wb[ABA]

    headers = {}
    for col_idx, cell in enumerate(ws[1], start=1):
        if cell.value is not None:
            headers[str(cell.value).strip()] = col_idx

    if "ID Preventiva" not in headers or "Status" not in headers:
        wb.close()
        raise ValueError(f"Colunas necessárias não encontradas: {list(headers.keys())}")

    c_idp = headers["ID Preventiva"]
    c_sta = headers["Status"]

    linha = None
    for r in range(2, ws.max_row + 1):
        v = ws.cell(r, c_idp).value
        if v is None:
            continue
        try:
            v = int(float(str(v).strip()))
        except:
            continue

        if v == int(id_prev):
            linha = r
            break

    if linha is None:
        wb.close()
        raise ValueError(f"ID Preventiva {id_prev} não encontrado.")

    ws.cell(linha, c_sta).value = "OK"

    wb.save(ARQUIVO)
    wb.close()



