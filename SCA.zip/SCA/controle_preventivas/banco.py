import sqlite3

DB = "preventivas.db"


def conectar():
    return sqlite3.connect(DB)


def _colunas_da_tabela(cursor, tabela: str) -> set[str]:
    cursor.execute(f"PRAGMA table_info({tabela})")
    return {row[1] for row in cursor.fetchall()}  # row[1] = nome da coluna


def criar_tabelas():
    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY,
        nome TEXT NOT NULL,
        senha TEXT NOT NULL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS preventiva (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        maquina TEXT,
        descricao TEXT,
        tecnico TEXT,
        data_prevista TEXT,
        data_realizada TEXT,
        status TEXT
    )
    """)

    # ===== MIGRAÇÃO AUTOMÁTICA =====
    cols = _colunas_da_tabela(cursor, "preventiva")

    if "finalizado_por_id" not in cols:
        cursor.execute("ALTER TABLE preventiva ADD COLUMN finalizado_por_id INTEGER")

    if "finalizado_por_nome" not in cols:
        cursor.execute("ALTER TABLE preventiva ADD COLUMN finalizado_por_nome TEXT")

    conn.commit()
    conn.close()
