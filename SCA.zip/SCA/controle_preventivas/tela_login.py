import tkinter as tk
from tkinter import messagebox
from banco import conectar
from tela_painel import TelaPainel
from tela_cadastro import TelaCadastro

class TelaLogin:

    def __init__(self):
        self.janela = tk.Tk()
        self.janela.title("Login - Sistema de Preventivas")
        self.janela.geometry("350x240")
        self.janela.resizable(False, False)

        tk.Label(self.janela, text="ID").pack(pady=5)
        self.entry_id = tk.Entry(self.janela)
        self.entry_id.pack(pady=5)

        tk.Label(self.janela, text="Senha").pack(pady=5)
        self.entry_senha = tk.Entry(self.janela, show="*")
        self.entry_senha.pack(pady=5)

        frame_btn = tk.Frame(self.janela)
        frame_btn.pack(pady=15)

        tk.Button(frame_btn, text="Entrar", command=self.login, bg="#2ecc71", fg="white", width=12).pack(side="left", padx=6)
        tk.Button(frame_btn, text="Cadastrar", command=self.abrir_cadastro, bg="#3498db", fg="white", width=12).pack(side="left", padx=6)

        self.janela.mainloop()

    def abrir_cadastro(self):
        # abre tela de cadastro separada
        TelaCadastro()

    def login(self):
        try:
            user_id = int(self.entry_id.get().strip())
        except:
            messagebox.showerror("Erro", "ID inválido.")
            return

        senha = self.entry_senha.get().strip()

        if not senha:
            messagebox.showwarning("Aviso", "Digite a senha.")
            return

        conn = conectar()
        cursor = conn.cursor()

        cursor.execute("SELECT nome FROM usuarios WHERE id=? AND senha=?", (user_id, senha))
        row = cursor.fetchone()
        conn.close()

        if not row:
            messagebox.showerror("Erro", "ID ou senha incorretos.")
            return

        nome = row[0]
        self.janela.destroy()

        # passa o nome do usuário logado para registrar no histórico
        TelaPainel(user_id, nome)
