import tkinter as tk
from tkinter import messagebox
from banco import conectar

class TelaCadastro:

    def __init__(self):
        self.janela = tk.Tk()
        self.janela.title("Cadastro - Sistema de Preventivas")
        self.janela.geometry("380x260")
        self.janela.resizable(False, False)

        tk.Label(self.janela, text="ID (numérico)").pack(pady=5)
        self.entry_id = tk.Entry(self.janela)
        self.entry_id.pack()

        tk.Label(self.janela, text="Nome").pack(pady=5)
        self.entry_nome = tk.Entry(self.janela)
        self.entry_nome.pack()

        tk.Label(self.janela, text="Senha").pack(pady=5)
        self.entry_senha = tk.Entry(self.janela, show="*")
        self.entry_senha.pack()

        tk.Button(self.janela, text="Cadastrar", command=self.cadastrar, bg="#3498db", fg="white").pack(pady=15)

        self.janela.mainloop()

    def cadastrar(self):
        try:
            user_id = int(self.entry_id.get().strip())
        except:
            messagebox.showerror("Erro", "ID deve ser numérico.")
            return

        nome = self.entry_nome.get().strip()
        senha = self.entry_senha.get().strip()

        if not nome or not senha:
            messagebox.showwarning("Aviso", "Preencha Nome e Senha.")
            return

        conn = conectar()
        cursor = conn.cursor()

        try:
            cursor.execute("INSERT INTO usuarios (id, nome, senha) VALUES (?, ?, ?)", (user_id, nome, senha))
            conn.commit()
            messagebox.showinfo("OK", "Usuário cadastrado com sucesso!")
            self.janela.destroy()
        except Exception as e:
            messagebox.showerror("Erro", f"Não foi possível cadastrar. Talvez ID já exista.\n\n{e}")
        finally:
            conn.close()
