import tkinter as tk
from tkinter import ttk, messagebox
from banco import conectar
from datetime import datetime
from excel_manager import carregar_pendentes, finalizar_preventiva


class TelaPainel:

    def __init__(self, user_id, nome):

        self.user_id = user_id
        self.nome = nome

        self.janela = tk.Tk()
        self.janela.title(f"Painel - {self.nome} ({self.user_id})")
        self.janela.geometry("980x520")

        self.criar_abas()

        self.carregar_pendentes()
        self.carregar_fechadas()

        self.janela.mainloop()

    # =========================
    # UI
    # =========================

    def criar_abas(self):

        abas = ttk.Notebook(self.janela)
        abas.pack(fill="both", expand=True)

        self.frame_pendentes = tk.Frame(abas)
        self.frame_fechadas = tk.Frame(abas)

        abas.add(self.frame_pendentes, text="Preventivas Pendentes")
        abas.add(self.frame_fechadas, text="Preventivas Fechadas")

        # ---- Pendentes ----
        topo_pend = tk.Frame(self.frame_pendentes)
        topo_pend.pack(fill="x", padx=10, pady=8)

        tk.Button(topo_pend, text="Atualizar", command=self.carregar_pendentes).pack(side="left", padx=5)
        tk.Button(topo_pend, text="Finalizar Preventiva", command=self.finalizar).pack(side="left", padx=5)

        self.lbl_info_pend = tk.Label(
            topo_pend,
            text=f"Logado: {self.nome} (ID: {self.user_id})",
            font=("Arial", 10, "bold")
        )
        self.lbl_info_pend.pack(side="right", padx=5)

        self.tabela_pendentes = ttk.Treeview(
            self.frame_pendentes,
            columns=("ID Preventiva","ID", "Maquina", "Descricao", "Tecnico", "Data Prevista"),
            show="headings"
        )
        for col in ("ID", "Maquina", "Descricao", "Tecnico", "Data Prevista"):
            self.tabela_pendentes.heading(col, text=col)

        self.tabela_pendentes.pack(fill="both", expand=True, padx=10, pady=10)

        # ---- Fechadas ----
        topo_fech = tk.Frame(self.frame_fechadas)
        topo_fech.pack(fill="x", padx=10, pady=8)

        tk.Button(topo_fech, text="Atualizar", command=self.carregar_fechadas).pack(side="left", padx=5)

        self.lbl_info_fech = tk.Label(
            topo_fech,
            text=f"Logado: {self.nome} (ID: {self.user_id})",
            font=("Arial", 10, "bold")
        )
        self.lbl_info_fech.pack(side="right", padx=5)

        self.tabela_fechadas = ttk.Treeview(
            self.frame_fechadas,
            columns=("Maquina", "Descricao", "Tecnico", "Prevista", "Realizada", "Finalizado por", "ID Finalizador"),
            show="headings"
        )
        for col in ("Maquina", "Descricao", "Tecnico", "Prevista", "Realizada", "Finalizado por", "ID Finalizador"):
            self.tabela_fechadas.heading(col, text=col)

        self.tabela_fechadas.pack(fill="both", expand=True, padx=10, pady=10)

    # =========================
    # Carregar dados
    # =========================

    def carregar_pendentes(self):

        for item in self.tabela_pendentes.get_children():
            self.tabela_pendentes.delete(item)

        try:
            df = carregar_pendentes()

            if df.empty:
                return

            for _, linha in df.iterrows():
                self.tabela_pendentes.insert(
                    "",
                    "end",
                    values=(
                        int(linha["ID Preventiva"]),
                        int(linha["ID"]),
                        linha["Maquina"],
                        linha["Descricao"],
                        linha["Tecnico"],
                        linha["Data Prevista"]
                    )
                )

        except Exception as e:
            messagebox.showerror("Erro ao carregar pendentes", str(e))

    def carregar_fechadas(self):

        for item in self.tabela_fechadas.get_children():
            self.tabela_fechadas.delete(item)

        conn = conectar()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                SELECT maquina, descricao, tecnico,
                       data_prevista, data_realizada,
                       finalizado_por_nome, finalizado_por_id
                FROM preventiva
                WHERE status='REALIZADA'
                ORDER BY data_realizada DESC
            """)
            dados = cursor.fetchall()

            for d in dados:
                self.tabela_fechadas.insert("", "end", values=d)

        finally:
            conn.close()

    # =========================
    # Finalizar preventiva
    # =========================

    def finalizar(self):

        selecionado = self.tabela_pendentes.selection()
        if not selecionado:
            messagebox.showwarning("Aviso", "Selecione uma preventiva")
            return

        item_id = selecionado[0]
        valores = self.tabela_pendentes.item(item_id)["values"]

        id_prev = int(valores[0])
        id_tecnico = int(valores[1])
        maquina = valores[2]
        descricao = valores[3]
        tecnico = valores[4]
        data_prevista = valores[5]

        try:
            # 1) Atualiza SOMENTE aquela linha no Excel (Status = OK)
            finalizar_preventiva(
                id_prev,
                
            )

            # 2) Salva no banco (auditoria)
            conn = conectar()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO preventiva
                (maquina, descricao, tecnico, data_prevista, data_realizada,
                 finalizado_por_id, finalizado_por_nome, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'REALIZADA')
            """, (
                maquina,
                descricao,
                tecnico,
                str(data_prevista),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                self.user_id,
                self.nome
            ))

            conn.commit()
            conn.close()

            messagebox.showinfo("OK", f"Preventiva {id_prev} finalizada")
            self.tabela_pendentes.delete(item_id)
            self.carregar_pendentes()
            self.carregar_fechadas()

        except Exception as e:
            messagebox.showerror("Erro ao finalizar", str(e))
