from banco import criar_tabelas
from tela_login import TelaLogin


def main():

    # cria as tabelas do banco se não existirem
    criar_tabelas()

    # inicia tela de login
    TelaLogin()


if __name__ == "__main__":
    main()
