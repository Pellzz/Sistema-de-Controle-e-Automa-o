import sqlite3

DB = "preventivas.db"

def migrar():
    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    # tenta adicionar colunas; se já existirem, ignora
    try:
        cur.execute("ALTER TABLE preventiva ADD COLUMN finalizado_por_id INTEGER")
    except sqlite3.OperationalError:
        pass

    try:
        cur.execute("ALTER TABLE preventiva ADD COLUMN finalizado_por_nome TEXT")
    except sqlite3.OperationalError:
        pass

    conn.commit()
    conn.close()
    print("Migração concluída com sucesso!")

if __name__ == "__main__":
    migrar()
